<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <!-- Judul Halaman -->
    <h1 class="text-center fw-bold position-relative pb-2"
        style="border-bottom: 4px solid #007bff; display: inline-block; padding-bottom: 10px;">
        Dakwah
    </h1>

    <div class="row mt-4">
        <!-- Kolom Kiri: Daftar Dakwah -->
        <div class="col-md-8">
            <div class="row">
                <?php $__currentLoopData = $dakwah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 mb-4">
                        <div class="card h-100 shadow-lg border-0"
                            style="transition: transform 0.2s, box-shadow 0.2s;">
                            <a href="<?php echo e(route('dakwah.detail', ['id' => $d->id])); ?>" class="text-decoration-none text-dark">
                                <!-- Gambar Dakwah -->
                                <img src="<?php echo e($d->image ? asset('storage/' . $d->image) : asset('images/default.jpg')); ?>"
                                    class="card-img-top img-fluid" 
                                    style="height: 200px; object-fit: cover;" 
                                    alt="<?php echo e($d->title); ?>">
                                <div class="card-body">
                                    <span class="text-primary fw-bold">Dakwah</span>
                                    <h5 class="card-title mt-2"><?php echo e($d->title); ?></h5>
                                    <p class="card-text"><?php echo e(Str::limit(strip_tags($d->content), 100)); ?></p>
                                    <hr>
                                    <div class="d-flex justify-content-between text-muted small">
                                        <span><i class="bi bi-person"></i> <?php echo e($d->admin); ?></span>
                                        <span><i class="bi bi-calendar"></i> <?php echo e(\Carbon\Carbon::parse($d->date)->format('d M Y')); ?></span>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <!-- Kolom Kanan: Sidebar -->
        <div class="col-md-4">
            <!-- Card Pencarian -->
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-primary text-white">Cari</div>
                <div class="card-body">
                    <input type="text" class="form-control" placeholder="Search...">
                </div>
            </div>

            <!-- Card Tentang Dakwah -->
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-primary text-white">Tentang Dakwah</div>
                <div class="card-body">
                    <p>Dakwah adalah aktivitas menyampaikan ajaran Islam kepada umat. Temukan berbagai materi dan kegiatan dakwah di sini.</p>
                </div>
            </div>

            <!-- Card Temukan Kami -->
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-primary text-white">Temukan Kami</div>
                <div class="card-body">
                    <p><strong>Alamat:</strong> <br>
                        Jl. Taman Siswa, Klp. Sawit, Padasugih, Kec. Brebes, Kabupaten Brebes, Jawa Tengah 52214</p>
                    <p><strong>Jam Buka:</strong> <br>
                        Senin—Sabtu: 08:00–16:00</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutfrontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sifkames\resources\views/frontend/dakwah/index.blade.php ENDPATH**/ ?>