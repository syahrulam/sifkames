<?php $__env->startSection('content'); ?>
<div class="container-fluid px-0">
    <!-- Header dengan gambar background -->
    <div class="position-relative" style="height: 350px; background: url('<?php echo e(asset($aktivitas->image)); ?>') center/cover;">
        <div class="overlay position-absolute w-100 h-100" style="background: rgba(0, 0, 0, 0.5);"></div>
        <div class="position-absolute top-50 start-50 translate-middle text-white text-center">
            <h1 class="fw-bold"><?php echo e($aktivitas->title); ?></h1>
            <p class="mt-2"><i class="bi bi-person"></i> Admin &nbsp; | &nbsp; <i class="bi bi-calendar"></i> <?php echo e(\Carbon\Carbon::parse($aktivitas->date)->format('d M Y')); ?></p>
        </div>
    </div>

    <!-- Bagian Konten -->
    <div class="container mt-4">
        <!-- Bagikan ke Sosial Media -->
        <div class="d-flex justify-content-center mb-3">
            <a href="#" class="btn btn-primary mx-1"><i class="bi bi-facebook"></i></a>
            <a href="#" class="btn btn-info mx-1"><i class="bi bi-twitter"></i></a>
            <a href="#" class="btn btn-dark mx-1"><i class="bi bi-instagram"></i></a>
            <a href="#" class="btn btn-success mx-1"><i class="bi bi-whatsapp"></i></a>
            <a href="#" class="btn btn-secondary mx-1"><i class="bi bi-share"></i></a>
        </div>

        <!-- Jumlah Dilihat -->
        <p class="text-center text-muted"><i class="bi bi-bar-chart"></i> 14 total dilihat</p>

        <!-- Gambar Setelah Statistik -->
        <div class="text-center my-4">
            <img src="<?php echo e(asset($aktivitas->image)); ?>" class="img-fluid rounded shadow-lg" alt="<?php echo e($aktivitas->title); ?>">
        </div>

        <!-- Konten Detail -->
        <div class="mx-auto" style="max-width: 800px;">
            <p class="lead text-justify" style="line-height: 1.8;">
                <?php echo e($aktivitas->content); ?>

            </p>
        </div>

        <!-- Tombol Kembali -->
         <div class="text-center mt-5 mb-5">
            <a href="<?php echo e(route('gebermas')); ?>" class="btn btn-primary px-4 py-2 rounded-pill shadow">
                <i class="bi bi-arrow-left"></i> Kembali
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutfrontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sifkames\resources\views/frontend/gebermas/detail.blade.php ENDPATH**/ ?>