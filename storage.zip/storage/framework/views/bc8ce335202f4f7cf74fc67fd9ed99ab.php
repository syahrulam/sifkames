<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h2>Kepengurusan</h2>
        <p>Ini adalah halaman Kepengurusan.</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutfrontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sifkames\resources\views/frontend/team/index.blade.php ENDPATH**/ ?>