<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4>Daftar Kegiatan Muslim Medical</h4>
                </div>
                <div class="card-body">

                    <!-- Tombol Tambah Kegiatan -->
                    <div class="d-flex justify-content-end mb-3">
                        <a href="<?php echo e(route('admin.muslim_medical.create')); ?>" class="btn btn-primary">Tambah Kegiatan</a>
                    </div>

                    <!-- Notifikasi Sukses -->
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>

                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Judul</th>
                                <th>Tanggal</th>
                                <th>Gambar</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->title); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($item->date)->format('d M Y')); ?></td>
                                    <td>
                                        <img src="<?php echo e(asset('storage/' . $item->image)); ?>" alt="<?php echo e($item->title); ?>" width="100">
                                    </td>
                                    <td>
                                        <!-- Tombol Edit -->
                                        <a href="<?php echo e(route('admin.muslim_medical.edit', $item->id)); ?>" class="btn btn-warning btn-sm">Edit</a>

                                        <!-- Form Tombol Delete -->
                                        <form action="<?php echo e(route('admin.muslim_medical.destroy', $item->id)); ?>" method="POST" style="display:inline-block;" id="delete-form-<?php echo e($item->id); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="button" class="btn btn-danger btn-sm" onclick="confirmDelete(<?php echo e($item->id); ?>)">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div> <!-- End .card-body -->
            </div> <!-- End .card -->
        </div> <!-- End .col-12 -->
    </div> <!-- End .row -->
</section>

<script>
    function confirmDelete(itemId) {
        if (confirm('Apakah Anda yakin ingin menghapus kegiatan ini?')) {
            document.getElementById('delete-form-' + itemId).submit();
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutbackend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sifkames\resources\views/backend/muslim_medical/index.blade.php ENDPATH**/ ?>